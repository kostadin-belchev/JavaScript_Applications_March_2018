async function startApp() {
   
    loadHeader();
    loadHome();
}
    