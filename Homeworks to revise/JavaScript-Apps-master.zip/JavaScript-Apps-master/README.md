# JavaScript-Apps
This repository contains resources and activities associated with the JavaScript Applications course in SoftUni.
