function startApp() {
    showHideMenuLinks();
    showView('viewHome');
    attachEvents();
}