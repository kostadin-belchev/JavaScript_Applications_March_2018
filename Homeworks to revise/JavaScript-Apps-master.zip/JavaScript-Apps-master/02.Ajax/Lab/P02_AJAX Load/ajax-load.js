function loadTitle() {

  $('#text').load("text.html");

}